from wstore.asset_manager.resource_plugins.plugin import ServicePlugin

class TestPlugin(ServicePlugin):
    pass
