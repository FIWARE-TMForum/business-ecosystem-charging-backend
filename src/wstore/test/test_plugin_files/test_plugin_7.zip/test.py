from wstore.asset_manager.resource_plugins.plugin import ServicePlugin

class TestPlugin(ServicePlugin):
    def get_pending_accounting(asset, contract, order):
        pass
